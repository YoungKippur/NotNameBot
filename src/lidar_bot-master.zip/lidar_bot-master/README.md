### Lidarbot V2
Hello and welcome to the new and improved Lidarbot project.

